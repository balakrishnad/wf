import React from 'react';

export default class CompleteForm extends React.Component{

    render(){
        return (
            <label id ="completeHeader" >Request completed</label>
        )
    }
}
